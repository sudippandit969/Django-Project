from . models import Student
import time
def run_this_function():
    print("Function started")
    
    print("Function Executed...") 
    time.sleep(1)